package com.rli.scripts.customobjects.restclient.httpclient;

import java.util.Map;

/*
 * Class for any Exception while using the Http Client and Workday API Client
 */
public class ApiException extends Exception {

	private static final long serialVersionUID = 1L;
	
	private Integer httpCode = 0; 
	private Integer apiErrorCode = 0;
    private Map<String, String> responseHeaders = null;
    
    public ApiException(String message) {
    	super(message);
    }
    
    public ApiException(Integer httpCode, Integer apiErrorCode, Map<String, String> responseHeaders, String message) {
    	super(message);
        this.httpCode = httpCode;
        this.apiErrorCode = apiErrorCode;
        this.responseHeaders = responseHeaders;
    }
    
    public Integer getHttpCode() {
        return httpCode;
    }
    
    public Integer getApiErrorCode() {
        return apiErrorCode;
    }
    
    public Map<String, String> getResponseHeaders() {
        return responseHeaders;
    }
}
