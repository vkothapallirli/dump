package com.rli.scripts.customobjects.workday.organization;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

/*
 * Class representing the Response body for Get All Organizations API Call
 */
public class GetAllOrganizationsResponse {
	
	@SerializedName("Report_Entry")
	private List<Organization> organizations = null;

	public GetAllOrganizationsResponse organizations(List<Organization> organizations) {
		this.organizations = organizations;
		return this;
	}
	
	public GetAllOrganizationsResponse addOrganizationsItem(Organization organization) {
		if(this.organizations == null && organization != null && !organization.isEmpty())
			this.organizations = new ArrayList<Organization>();
		if(organization != null && !organization.isEmpty())
			this.organizations.add(organization);
		return this;
	}

	public List<Organization> getOrganizations() {
		return organizations;
	}

	public void setOrganizations(List<Organization> organizations) {
		if(organizations != null && !organizations.isEmpty())
			this.organizations = organizations;
	}

	public Boolean isEmpty() {
		return (
				(organizations == null || organizations.isEmpty())
				);

	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class GetAllOrganizationsResponse {\n");
		sb.append("    organizations: ").append(toIndentedString(organizations)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
