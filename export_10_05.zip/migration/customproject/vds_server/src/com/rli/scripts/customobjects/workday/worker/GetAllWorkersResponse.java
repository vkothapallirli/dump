package com.rli.scripts.customobjects.workday.worker;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

/*
 * Class representing the Response body for Get All Workers API Call
 */
public class GetAllWorkersResponse {
	
	@SerializedName("Report_Entry")
	private List<Worker> workers = null;

	public GetAllWorkersResponse workers(List<Worker> workers) {
		this.workers = workers;
		return this;
	}
	
	public GetAllWorkersResponse addWorkersItem(Worker worker) {
		if(this.workers == null && worker != null && !worker.isEmpty())
			this.workers = new ArrayList<Worker>();
		if(worker != null && !worker.isEmpty())
			this.workers.add(worker);
		return this;
	}

	public List<Worker> getWorkers() {
		return workers;
	}

	public void setWorkers(List<Worker> workers) {
		if(workers != null && !workers.isEmpty())
			this.workers = workers;
	}

	public Boolean isEmpty() {
		return (
				(workers == null || workers.isEmpty())
				);

	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class GetAllWorkersResponse {\n");
		sb.append("    workers: ").append(toIndentedString(workers)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
