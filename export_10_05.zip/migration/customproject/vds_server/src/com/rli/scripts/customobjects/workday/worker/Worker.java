package com.rli.scripts.customobjects.workday.worker;

import java.time.LocalDate;

import com.google.gson.annotations.SerializedName;

/*
 * Class representing a Worker
 */
public class Worker {
	
	@SerializedName("ACTIVE_STATUS")
	private Boolean activeStatus;
	
	@SerializedName("BEGDA")
	private LocalDate beginDate;
	
	@SerializedName("BUSINESS_TITLE")
	private String businessTitle;
	
	@SerializedName("DEPT_CODE")
	private String departmentCode;
	
	@SerializedName("DUTY_CODE")
	private String dutyCode;
	
	@SerializedName("E_MAIL")
	private String emailAddress;
	
	@SerializedName("EMP_CODE")
	private String employeeCode;
	
	@SerializedName("Employment")
	private String employment;
	
	@SerializedName("ENDDA")
	private LocalDate endDate;
	
	@SerializedName("IS_MANAGER")
	private Boolean isManager;
	
	@SerializedName("JobFamily")
	private String jobFamily;
	
	@SerializedName("JobFamilyGroup")
	private String jobFamilyGroup;
	
	@SerializedName("JobProfile")
	private String jobProfile;
	
	@SerializedName("LOCATION")
	private String location;
	
	@SerializedName("Manager")
	private String managerName;
	
	@SerializedName("ManagerID")
	private String managerID;
	
	@SerializedName("mgr1")
	private String manager1;
	
	@SerializedName("mgr2")
	private String manager2;
	
	@SerializedName("mgr3")
	private String manager3;
	
	@SerializedName("mgr4")
	private String manager4;
	
	@SerializedName("mgr5")
	private String manager5;
	
	@SerializedName("mgr6")
	private String manager6;
	
	@SerializedName("mgr7")
	private String manager7;
	
	@SerializedName("mgr8")
	private String manager8;
	
	@SerializedName("mgr9")
	private String manager9;
	
	@SerializedName("MOBILE_PHONE")
	private String mobilePhone;
	
	@SerializedName("MODIFY_DATE")
	private LocalDate modifyDate;
	
	@SerializedName("NAME")
	private String legalName;
	
	@SerializedName("NICK_NAME")
	private String nickName;
	
	@SerializedName("OFFICE")
	private String office;
	
	@SerializedName("org1")
	private String organization1;
	
	@SerializedName("org2")
	private String organization2;
	
	@SerializedName("org3")
	private String organization3;
	
	@SerializedName("org4")
	private String organization4;
	
	@SerializedName("org5")
	private String organization5;
	
	@SerializedName("org6")
	private String organization6;
	
	@SerializedName("org7")
	private String organization7;
	
	@SerializedName("org8")
	private String organization8;
	
	@SerializedName("org9")
	private String organization9;
	
	@SerializedName("PHONE")
	private String workPhone;
	
	@SerializedName("POS_CODE")
	private String positionCode;
	
	@SerializedName("POS_NAME")
	private String positionName;
	
	@SerializedName("SSN")
	private String ssn;
	
	@SerializedName("SupervisoryOrg")
	private String supervisoryOrganization;
	
	@SerializedName("Team")
	private String team;
	
	@SerializedName("USER_COLUMN16")
	private String managementLevel;
	
	@SerializedName("WORKER_TYPE_ID")
	private String workerTypeID;
	
	@SerializedName("WorkerSubType")
	private String workerSubType;
	
	@SerializedName("WorkerType")
	private String workerType;
	
	public Worker activeStatus(Boolean activeStatus) {
		this.activeStatus = activeStatus;
		return this;
	}

	public Boolean getActiveStatus() {
		if(activeStatus != null)
			return activeStatus;
		else
			return null;
	}

	public void setActiveStatus(Boolean activeStatus) {
		if(activeStatus != null)
			this.activeStatus = activeStatus;
	}
	
	public Worker beginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
		return this;
	}

	public LocalDate getBeginDate() {
		if(beginDate != null)
			return beginDate;
		else
			return null;
	}

	public void setBeginDate(LocalDate beginDate) {
		if(beginDate != null)
			this.beginDate = beginDate;
	}
	
	public Worker businessTitle(String businessTitle) {
		this.businessTitle = businessTitle;
		return this;
	}

	public String getBusinessTitle() {
		if(businessTitle != null && !businessTitle.isEmpty())
			return businessTitle;
		else
			return null;
	}

	public void setBusinessTitle(String businessTitle) {
		if(businessTitle != null)
			this.businessTitle = businessTitle;
	}
	
	public Worker departmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
		return this;
	}

	public String getDepartmentCode() {
		if(departmentCode != null && !departmentCode.isEmpty())
			return departmentCode;
		else
			return null;
	}

	public void setDepartmentCode(String departmentCode) {
		if(departmentCode != null && !departmentCode.equals(""))
			this.departmentCode = departmentCode;
	}
	
	public Worker dutyCode(String dutyCode) {
		this.dutyCode = dutyCode;
		return this;
	}

	public String getDutyCode() {
		if(dutyCode != null && !dutyCode.isEmpty())
			return dutyCode;
		else
			return null;
	}

	public void setDutyCode(String dutyCode) {
		if(dutyCode != null && !dutyCode.equals(""))
			this.dutyCode = dutyCode;
	}
	
	public Worker emailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
		return this;
	}

	public String getEmailAddress() {
		if(emailAddress != null && !emailAddress.isEmpty())
			return emailAddress;
		else
			return null;
	}

	public void setEmailAddress(String emailAddress) {
		if(emailAddress != null && !emailAddress.equals(""))
			this.emailAddress = emailAddress;
	}
	
	public Worker employeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
		return this;
	}

	public String getEmployeeCode() {
		if(employeeCode != null && !employeeCode.isEmpty())
			return employeeCode;
		else
			return null;
	}

	public void setEmployeeCode(String employeeCode) {
		if(employeeCode != null && !employeeCode.equals(""))
			this.employeeCode = employeeCode;
	}
	
	public Worker employment(String employment) {
		this.employment = employment;
		return this;
	}

	public String getEmployment() {
		if(employment != null && !employment.isEmpty())
			return employment;
		else
			return null;
	}

	public void setEmployment(String employment) {
		if(employment != null && !employment.equals(""))
			this.employment = employment;
	}
	
	public Worker endDate(LocalDate endDate) {
		this.endDate = endDate;
		return this;
	}

	public LocalDate getEndDate() {
		if(endDate != null)
			return endDate;
		else
			return null;
	}

	public void setEndDate(LocalDate endDate) {
		if(endDate != null)
			this.endDate = endDate;
	}
	
	public Worker isManager(Boolean isManager) {
		this.isManager = isManager;
		return this;
	}

	public Boolean getIsManager() {
		if(isManager != null)
			return isManager;
		else
			return null;
	}

	public void setIsManager(Boolean isManager) {
		if(isManager != null)
			this.isManager = isManager;
	}
	
	public Worker jobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
		return this;
	}

	public String getJobFamily() {
		if(jobFamily != null && !jobFamily.isEmpty())
			return jobFamily;
		else
			return null;
	}

	public void setJobFamily(String jobFamily) {
		if(jobFamily != null && !jobFamily.equals(""))
			this.jobFamily = jobFamily;
	}
	
	public Worker jobFamilyGroup(String jobFamilyGroup) {
		this.jobFamilyGroup = jobFamilyGroup;
		return this;
	}

	public String getJobFamilyGroup() {
		if(jobFamilyGroup != null && !jobFamilyGroup.isEmpty())
			return jobFamilyGroup;
		else
			return null;
	}

	public void setJobFamilyGroup(String jobFamilyGroup) {
		if(jobFamilyGroup != null && !jobFamilyGroup.equals(""))
			this.jobFamilyGroup = jobFamilyGroup;
	}
	
	public Worker jobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
		return this;
	}

	public String getJobProfile() {
		if(jobProfile != null && !jobProfile.isEmpty())
			return jobProfile;
		else
			return null;
	}

	public void setJobProfile(String jobProfile) {
		if(jobProfile != null && !jobProfile.equals(""))
			this.jobProfile = jobProfile;
	}
	
	public Worker location(String location) {
		this.location = location;
		return this;
	}

	public String getLocation() {
		if(location != null && !location.isEmpty())
			return location;
		else
			return null;
	}

	public void setLocation(String location) {
		if(location != null && !location.equals(""))
			this.location = location;
	}
	
	public Worker managerName(String managerName) {
		this.managerName = managerName;
		return this;
	}

	public String getManagerName() {
		if(managerName != null && !managerName.isEmpty())
			return managerName;
		else
			return null;
	}

	public void setManagerName(String managerName) {
		if(managerName != null && !managerName.equals(""))
			this.managerName = managerName;
	}
	
	public Worker managerID(String managerID) {
		this.managerID = managerID;
		return this;
	}

	public String getManagerID() {
		if(managerID != null && !managerID.isEmpty())
			return managerID;
		else
			return null;
	}

	public void setManagerID(String managerID) {
		if(managerID != null && !managerID.equals(""))
			this.managerID = managerID;
	}
	
	public Worker manager1(String manager1) {
		this.manager1 = manager1;
		return this;
	}

	public String getManager1() {
		if(manager1 != null && !manager1.isEmpty())
			return manager1;
		else
			return null;
	}

	public void setManager1(String manager1) {
		if(manager1 != null && !manager1.equals(""))
			this.manager1 = manager1;
	}
	
	public Worker manager2(String manager2) {
		this.manager2 = manager2;
		return this;
	}

	public String getManager2() {
		if(manager2 != null && !manager2.isEmpty())
			return manager2;
		else
			return null;
	}

	public void setManager2(String manager2) {
		if(manager2 != null && !manager2.equals(""))
			this.manager2 = manager2;
	}
	
	public Worker manager3(String manager3) {
		this.manager3 = manager3;
		return this;
	}

	public String getManager3() {
		if(manager3 != null && !manager3.isEmpty())
			return manager3;
		else
			return null;
	}

	public void setManager3(String manager3) {
		if(manager3 != null && !manager3.equals(""))
			this.manager3 = manager3;
	}
	
	public Worker manager4(String manager4) {
		this.manager4 = manager4;
		return this;
	}

	public String getManager4() {
		if(manager4 != null && !manager4.isEmpty())
			return manager4;
		else
			return null;
	}

	public void setManager4(String manager4) {
		if(manager4 != null && !manager4.equals(""))
			this.manager4 = manager4;
	}
	
	public Worker manager5(String manager5) {
		this.manager5 = manager5;
		return this;
	}

	public String getManager5() {
		if(manager5 != null && !manager5.isEmpty())
			return manager5;
		else
			return null;
	}

	public void setManager5(String manager5) {
		if(manager5 != null && !manager5.equals(""))
			this.manager5 = manager5;
	}
	
	public Worker manager6(String manager6) {
		this.manager6 = manager6;
		return this;
	}

	public String getManager6() {
		if(manager6 != null && !manager6.isEmpty())
			return manager6;
		else
			return null;
	}

	public void setManager6(String manager6) {
		if(manager6 != null && !manager6.equals(""))
			this.manager6 = manager6;
	}
	
	public Worker manager7(String manager7) {
		this.manager7 = manager7;
		return this;
	}

	public String getManager7() {
		if(manager7 != null && !manager7.isEmpty())
			return manager7;
		else
			return null;
	}

	public void setManager7(String manager7) {
		if(manager7 != null && !manager7.equals(""))
			this.manager7 = manager7;
	}
	
	public Worker manager8(String manager8) {
		this.manager8 = manager8;
		return this;
	}

	public String getManager8() {
		if(manager8 != null && !manager8.isEmpty())
			return manager8;
		else
			return null;
	}

	public void setManager8(String manager8) {
		if(manager8 != null && !manager8.equals(""))
			this.manager8 = manager8;
	}
	
	public Worker manager9(String manager9) {
		this.manager9 = manager9;
		return this;
	}

	public String getManager9() {
		if(manager9 != null && !manager9.isEmpty())
			return manager9;
		else
			return null;
	}

	public void setManager9(String manager9) {
		if(manager9 != null && !manager9.equals(""))
			this.manager9 = manager9;
	}
	
	public Worker mobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
		return this;
	}

	public String getMobilePhone() {
		if(mobilePhone != null && !mobilePhone.isEmpty())
			return mobilePhone;
		else
			return null;
	}

	public void setMobilePhone(String mobilePhone) {
		if(mobilePhone != null && !mobilePhone.equals(""))
			this.mobilePhone = mobilePhone;
	}
	
	public Worker modifyDate(LocalDate modifyDate) {
		this.modifyDate = modifyDate;
		return this;
	}

	public LocalDate getModifyDate() {
		if(modifyDate != null)
			return modifyDate;
		else
			return null;
	}

	public void setModifyDate(LocalDate modifyDate) {
		if(modifyDate != null)
			this.modifyDate = modifyDate;
	}
	
	public Worker legalName(String legalName) {
		this.legalName = legalName;
		return this;
	}

	public String getLegalName() {
		if(legalName != null && !legalName.isEmpty())
			return legalName;
		else
			return null;
	}

	public void setLegalName(String legalName) {
		if(legalName != null && !legalName.equals(""))
			this.legalName = legalName;
	}
	
	public Worker nickName(String nickName) {
		this.nickName = nickName;
		return this;
	}

	public String getNickName() {
		if(nickName != null && !nickName.isEmpty())
			return nickName;
		else
			return null;
	}

	public void setNickName(String nickName) {
		if(nickName != null && !nickName.equals(""))
			this.nickName = nickName;
	}
	
	public Worker office(String office) {
		this.office = office;
		return this;
	}

	public String getOffice() {
		if(office != null && !office.isEmpty())
			return office;
		else
			return null;
	}

	public void setOffice(String office) {
		if(office != null && !office.equals(""))
			this.office = office;
	}
	
	public Worker organization1(String organization1) {
		this.organization1 = organization1;
		return this;
	}

	public String getOrganization1() {
		if(organization1 != null && !organization1.isEmpty())
			return organization1;
		else
			return null;
	}

	public void setOrganization1(String organization1) {
		if(organization1 != null && !organization1.equals(""))
			this.organization1 = organization1;
	}
	
	public Worker organization2(String organization2) {
		this.organization2 = organization2;
		return this;
	}

	public String getOrganization2() {
		if(organization2 != null && !organization2.isEmpty())
			return organization2;
		else
			return null;
	}

	public void setOrganization2(String organization2) {
		if(organization2 != null && !organization2.equals(""))
			this.organization2 = organization2;
	}
	
	public Worker organization3(String organization3) {
		this.organization3 = organization3;
		return this;
	}

	public String getOrganization3() {
		if(organization3 != null && !organization3.isEmpty())
			return organization3;
		else
			return null;
	}

	public void setOrganization3(String organization3) {
		if(organization3 != null && !organization3.equals(""))
			this.organization3 = organization3;
	}
	
	public Worker organization4(String organization4) {
		this.organization4 = organization4;
		return this;
	}

	public String getOrganization4() {
		if(organization4 != null && !organization4.isEmpty())
			return organization4;
		else
			return null;
	}

	public void setOrganization4(String organization4) {
		if(organization4 != null && !organization4.equals(""))
			this.organization4 = organization4;
	}
	
	public Worker organization5(String organization5) {
		this.organization5 = organization5;
		return this;
	}

	public String getOrganization5() {
		if(organization5 != null && !organization5.isEmpty())
			return organization5;
		else
			return null;
	}

	public void setOrganization5(String organization5) {
		if(organization5 != null && !organization5.equals(""))
			this.organization5 = organization5;
	}
	
	public Worker organization6(String organization6) {
		this.organization6 = organization6;
		return this;
	}

	public String getOrganization6() {
		if(organization6 != null && !organization6.isEmpty())
			return organization6;
		else
			return null;
	}

	public void setOrganization6(String organization6) {
		if(organization6 != null && !organization6.equals(""))
			this.organization6 = organization6;
	}
	
	public Worker organization7(String organization7) {
		this.organization7 = organization7;
		return this;
	}

	public String getOrganization7() {
		if(organization7 != null && !organization7.isEmpty())
			return organization7;
		else
			return null;
	}

	public void setOrganization7(String organization7) {
		if(organization7 != null && !organization7.equals(""))
			this.organization7 = organization7;
	}
	
	public Worker organization8(String organization8) {
		this.organization8 = organization8;
		return this;
	}

	public String getOrganization8() {
		if(organization8 != null && !organization8.isEmpty())
			return organization8;
		else
			return null;
	}

	public void setOrganization8(String organization8) {
		if(organization8 != null && !organization8.equals(""))
			this.organization8 = organization8;
	}
	
	public Worker organization9(String organization9) {
		this.organization9 = organization9;
		return this;
	}

	public String getOrganization9() {
		if(organization9 != null && !organization9.isEmpty())
			return organization9;
		else
			return null;
	}

	public void setOrganization9(String organization9) {
		if(organization9 != null && !organization9.equals(""))
			this.organization9 = organization9;
	}
	
	public Worker workPhone(String workPhone) {
		this.workPhone = workPhone;
		return this;
	}

	public String getWorkPhone() {
		if(workPhone != null && !workPhone.isEmpty())
			return workPhone;
		else
			return null;
	}

	public void setWorkPhone(String workPhone) {
		if(workPhone != null && !workPhone.equals(""))
			this.workPhone = workPhone;
	}
	
	public Worker positionCode(String positionCode) {
		this.positionCode = positionCode;
		return this;
	}

	public String getPositionCode() {
		if(positionCode != null && !positionCode.isEmpty())
			return positionCode;
		else
			return null;
	}

	public void setPositionCode(String positionCode) {
		if(positionCode != null && !positionCode.equals(""))
			this.positionCode = positionCode;
	}
	
	public Worker positionName(String positionName) {
		this.positionName = positionName;
		return this;
	}

	public String getPositionName() {
		if(positionName != null && !positionName.isEmpty())
			return positionName;
		else
			return null;
	}

	public void setPositionName(String positionName) {
		if(positionName != null && !positionName.equals(""))
			this.positionName = positionName;
	}
	
	public Worker ssn(String ssn) {
		this.ssn = ssn;
		return this;
	}

	public String getSsn() {
		if(ssn != null && !ssn.isEmpty())
			return ssn;
		else
			return null;
	}

	public void setSsn(String ssn) {
		if(ssn != null && !ssn.equals(""))
			this.ssn = ssn;
	}
	
	public Worker supervisoryOrganization(String supervisoryOrganization) {
		this.supervisoryOrganization = supervisoryOrganization;
		return this;
	}

	public String getSupervisoryOrganization() {
		if(supervisoryOrganization != null && !supervisoryOrganization.isEmpty())
			return supervisoryOrganization;
		else
			return null;
	}

	public void setSupervisoryOrganization(String supervisoryOrganization) {
		if(supervisoryOrganization != null && !supervisoryOrganization.equals(""))
			this.supervisoryOrganization = supervisoryOrganization;
	}
	
	public Worker team(String team) {
		this.team = team;
		return this;
	}

	public String getTeam() {
		if(team != null && !team.isEmpty())
			return team;
		else
			return null;
	}

	public void setTeam(String team) {
		if(team != null && !team.equals(""))
			this.team = team;
	}
	
	public Worker managementLevel(String managementLevel) {
		this.managementLevel = managementLevel;
		return this;
	}

	public String getManagementLevel() {
		if(managementLevel != null && !managementLevel.isEmpty())
			return managementLevel;
		else
			return null;
	}

	public void setManagementLevel(String managementLevel) {
		if(managementLevel != null && !managementLevel.equals(""))
			this.managementLevel = managementLevel;
	}
	
	public Worker workerTypeID(String workerTypeID) {
		this.workerTypeID = workerTypeID;
		return this;
	}

	public String getWorkerTypeID() {
		if(workerTypeID != null && !workerTypeID.isEmpty())
			return workerTypeID;
		else
			return null;
	}

	public void setWorkerTypeID(String workerTypeID) {
		if(workerTypeID != null && !workerTypeID.equals(""))
			this.workerTypeID = workerTypeID;
	}
	
	public Worker workerSubType(String workerSubType) {
		this.workerSubType = workerSubType;
		return this;
	}

	public String getWorkerSubType() {
		if(workerSubType != null && !workerSubType.isEmpty())
			return workerSubType;
		else
			return null;
	}

	public void setWorkerSubType(String workerSubType) {
		if(workerSubType != null && !workerSubType.equals(""))
			this.workerSubType = workerSubType;
	}
	
	public Worker workerType(String workerType) {
		this.workerType = workerType;
		return this;
	}

	public String getWorkerType() {
		if(workerType != null && !workerType.isEmpty())
			return workerType;
		else
			return null;
	}

	public void setWorkerType(String workerType) {
		if(workerType != null && !workerType.equals(""))
			this.workerType = workerType;
	}
	
	public Boolean isEmpty() {
		return (
				(activeStatus == null) &&
				(beginDate == null) &&
				(businessTitle == null || businessTitle.isEmpty()) &&
				(departmentCode == null || departmentCode.isEmpty()) &&
				(dutyCode == null || dutyCode.isEmpty()) &&
				(emailAddress == null || emailAddress.isEmpty()) &&
				(employeeCode == null || employeeCode.isEmpty()) &&
				(employment == null || employment.isEmpty()) &&
				(endDate == null) &&
				(isManager == null) &&
				(jobFamily == null || jobFamily.isEmpty()) &&
				(jobFamilyGroup == null || jobFamilyGroup.isEmpty()) &&
				(jobProfile == null || jobProfile.isEmpty()) &&
				(location == null || location.isEmpty()) &&
				(managerName == null || managerName.isEmpty()) &&
				(managerID == null || managerID.isEmpty()) &&
				(manager1 == null || manager1.isEmpty()) &&
				(manager2 == null || manager2.isEmpty()) &&
				(manager3 == null || manager3.isEmpty()) &&
				(manager4 == null || manager4.isEmpty()) &&
				(manager5 == null || manager5.isEmpty()) &&
				(manager6 == null || manager6.isEmpty()) &&
				(manager7 == null || manager7.isEmpty()) &&
				(manager8 == null || manager8.isEmpty()) &&
				(manager9 == null || manager9.isEmpty()) &&
				(mobilePhone == null || mobilePhone.isEmpty()) &&
				(modifyDate == null) &&
				(legalName == null || legalName.isEmpty()) &&
				(nickName == null || nickName.isEmpty()) &&
				(office == null || office.isEmpty()) &&
				(organization1 == null || organization1.isEmpty()) &&
				(organization2 == null || organization2.isEmpty()) &&
				(organization3 == null || organization3.isEmpty()) &&
				(organization4 == null || organization4.isEmpty()) &&
				(organization5 == null || organization5.isEmpty()) &&
				(organization6 == null || organization6.isEmpty()) &&
				(organization7 == null || organization7.isEmpty()) &&
				(organization8 == null || organization8.isEmpty()) &&
				(organization9 == null || organization9.isEmpty()) &&
				(workPhone == null || workPhone.isEmpty()) &&
				(positionCode == null || positionCode.isEmpty()) &&
				(positionName == null || positionName.isEmpty()) &&
				(ssn == null || ssn.isEmpty()) &&
				(supervisoryOrganization == null || supervisoryOrganization.isEmpty()) &&
				(team == null || team.isEmpty()) &&
				(managementLevel == null || managementLevel.isEmpty()) &&
				(workerTypeID == null || workerTypeID.isEmpty()) &&
				(workerSubType == null || workerSubType.isEmpty()) &&
				(workerType == null || workerType.isEmpty())
				);

	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Worker {\n");
		sb.append("    activeStatus: ").append(toIndentedString(activeStatus)).append("\n");
		sb.append("    beginDate: ").append(toIndentedString(beginDate)).append("\n");
		sb.append("    businessTitle: ").append(toIndentedString(businessTitle)).append("\n");
		sb.append("    departmentCode: ").append(toIndentedString(departmentCode)).append("\n");
		sb.append("    dutyCode: ").append(toIndentedString(dutyCode)).append("\n");
		sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
		sb.append("    employeeCode: ").append(toIndentedString(employeeCode)).append("\n");
		sb.append("    employment: ").append(toIndentedString(employment)).append("\n");
		sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
		sb.append("    isManager: ").append(toIndentedString(isManager)).append("\n");
		sb.append("    jobFamily: ").append(toIndentedString(jobFamily)).append("\n");
		sb.append("    jobFamilyGroup: ").append(toIndentedString(jobFamilyGroup)).append("\n");
		sb.append("    jobProfile: ").append(toIndentedString(jobProfile)).append("\n");
		sb.append("    location: ").append(toIndentedString(location)).append("\n");
		sb.append("    managerName: ").append(toIndentedString(managerName)).append("\n");
		sb.append("    managerID: ").append(toIndentedString(managerID)).append("\n");
		sb.append("    manager1: ").append(toIndentedString(manager1)).append("\n");
		sb.append("    manager2: ").append(toIndentedString(manager2)).append("\n");
		sb.append("    manager3: ").append(toIndentedString(manager3)).append("\n");
		sb.append("    manager4: ").append(toIndentedString(manager4)).append("\n");
		sb.append("    manager5: ").append(toIndentedString(manager5)).append("\n");
		sb.append("    manager6: ").append(toIndentedString(manager6)).append("\n");
		sb.append("    manager7: ").append(toIndentedString(manager7)).append("\n");
		sb.append("    manager8: ").append(toIndentedString(manager8)).append("\n");
		sb.append("    manager9: ").append(toIndentedString(manager9)).append("\n");
		sb.append("    mobilePhone: ").append(toIndentedString(mobilePhone)).append("\n");
		sb.append("    modifyDate: ").append(toIndentedString(modifyDate)).append("\n");
		sb.append("    legalName: ").append(toIndentedString(legalName)).append("\n");
		sb.append("    nickName: ").append(toIndentedString(nickName)).append("\n");
		sb.append("    office: ").append(toIndentedString(office)).append("\n");
		sb.append("    organization1: ").append(toIndentedString(organization1)).append("\n");
		sb.append("    organization2: ").append(toIndentedString(organization2)).append("\n");
		sb.append("    organization3: ").append(toIndentedString(organization3)).append("\n");
		sb.append("    organization4: ").append(toIndentedString(organization4)).append("\n");
		sb.append("    organization5: ").append(toIndentedString(organization5)).append("\n");
		sb.append("    organization6: ").append(toIndentedString(organization6)).append("\n");
		sb.append("    organization7: ").append(toIndentedString(organization7)).append("\n");
		sb.append("    organization8: ").append(toIndentedString(organization8)).append("\n");
		sb.append("    organization9: ").append(toIndentedString(organization9)).append("\n");
		sb.append("    workPhone: ").append(toIndentedString(workPhone)).append("\n");
		sb.append("    positionCode: ").append(toIndentedString(positionCode)).append("\n");
		sb.append("    positionName: ").append(toIndentedString(positionName)).append("\n");
		sb.append("    ssn: ").append(toIndentedString(ssn)).append("\n");
		sb.append("    supervisoryOrganization: ").append(toIndentedString(supervisoryOrganization)).append("\n");
		sb.append("    team: ").append(toIndentedString(team)).append("\n");
		sb.append("    managementLevel: ").append(toIndentedString(managementLevel)).append("\n");
		sb.append("    workerTypeID: ").append(toIndentedString(workerTypeID)).append("\n");
		sb.append("    workerSubType: ").append(toIndentedString(workerSubType)).append("\n");
		sb.append("    workerType: ").append(toIndentedString(workerType)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
