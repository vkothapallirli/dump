package com.rli.scripts.customobjects.restclient.auth;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Class implementing HTTP Basic Auth
 */
public class HttpBasic {
	
	private static Logger logger = LogManager.getLogger(HttpBasic.class);
	
	private static String username = null;
	private static String password = null;
	private static String token = null;
	
	/*
	 * Set the Username and Password values
	 * Needs to be called prior to calling getToken()
	 */
	public static void setCredentials(String username, String password) {
		HttpBasic.username = username;
		HttpBasic.password = password;
	}
	
	/*
	 * Get a HTTP Basic based Auth Header
	 * Returns the existing token if the credentials have not changed and creates a new one if changed
	 */
	public static synchronized String getToken() {
		if(username == null || username.isEmpty() || password == null || password.isEmpty())
			throw new RuntimeException("username or password is not set - use setCredentials prior to calling getToken");
		
		if (token == null || !AuthUtils.verifyBasic(username, password, token)) {
			info("getToken", "Token is NULL - Generating new Token");
			token = AuthUtils.generateBasic(username, password);
		} else {
			info("getToken", "Token Exists - Returning Token");
		}
		
		return "Basic " + token;
	}
	
	/*
	 * Perform a hard reset on the token.
	 * Forces the getToken() to create a new token
	 */
	public static void forgetToken() {
		token = null;
	}
	
	private static void info(String method, String message) {
		logger.info("Method: " + method + " - " + message);
	}

}
