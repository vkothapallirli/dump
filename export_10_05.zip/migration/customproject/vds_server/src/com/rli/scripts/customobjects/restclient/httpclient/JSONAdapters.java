package com.rli.scripts.customobjects.restclient.httpclient;

import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

/*
 * Class that contain adapters for serializing and deserializing custom data types
 */
public class JSONAdapters {
	
	public JsonSerializer<LocalDate> createLocalDateSerializer = new JsonSerializer<LocalDate>() {
		@Override
		public JsonElement serialize(LocalDate src, Type typeOfSrc, JsonSerializationContext context) {
			if(src == null)
				return null;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
			return new JsonPrimitive(formatter.format(src));
		}
	};
		
	public JsonDeserializer<LocalDate> createLocalDateDeserializer = new JsonDeserializer<LocalDate>() {
		@Override
		public LocalDate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			if(json == null)
				return null;
			String dateString = json.getAsString();
			if(dateString == null || dateString.isEmpty())
				return null;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			return LocalDate.parse(dateString, formatter);
		}
	};

}
