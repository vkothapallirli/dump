package com.rli.scripts.customobjects.restclient.httpclient;

import java.io.StringReader;
import java.lang.reflect.Type;
import java.time.LocalDate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.stream.JsonReader;

/*
 * Class for serializing and deserializing - JSON Objects
 */
public class JSON {
    private Gson gson;
    private boolean isLenientOnJson = false;

    public JSON() {
    	GsonBuilder builder = new GsonBuilder();
    	JSONAdapters adapters = new JSONAdapters();
    	gson = builder
    			.registerTypeAdapter(LocalDate.class, adapters.createLocalDateSerializer)
    			.registerTypeAdapter(LocalDate.class, adapters.createLocalDateDeserializer)
    			.create();
    }

    public String serialize(Object obj) {
        return gson.toJson(obj);
    }

    @SuppressWarnings("unchecked")
    public <T> T deserialize(String body, Type returnType) {
        try {
            if (isLenientOnJson) {
                JsonReader jsonReader = new JsonReader(new StringReader(body));
                jsonReader.setLenient(true);
                return gson.fromJson(jsonReader, returnType);
            } else {
                return gson.fromJson(body, returnType);
            }
        } catch (JsonParseException e) {
            if (returnType.equals(String.class))
                return (T) body;
            else throw (e);
        }
    }
}
