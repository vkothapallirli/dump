package com.rli.scripts.customobjects.restclient.httpclient;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
 * Class for representing and executing HTTP requests
 */
public class ApiRequest {
	
	private static Logger logger = LogManager.getLogger(ApiRequest.class);
	
	private URI url = null;
	private Map<String,String> headers = new HashMap<>();
	public enum HttpMethod {
		GET("GET"),
		POST("POST"),
		PATCH("PATCH"),
		PUT("PUT"),
		DELETE("DELETE");

		private String value;

		HttpMethod(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}

		@Override
		public String toString() {
			return String.valueOf(value);
		}
	}
	private HttpMethod method = null;
	private String body = null;
	
	private RequestConfig requestConfig = null;
	
	public URI getUrl() {
		return url;
	}

	public void setUrl(URI url) {
		this.url = url;
	}

	public HttpMethod getMethod() {
		return method;
	}

	public void setMethod(HttpMethod method) {
		this.method = method;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}
	
	public String getHeader(String key) {
		return headers.get(key);
	}

	public void addHeader(String key, String value) {
		this.headers.put(key, value);
	}
	
	public void removeHeader(String key) {
		this.headers.remove(key);
	}
	
	public void removeHeaderValue(String key, String value) {
		this.headers.remove(key, value);
	}
	
	public String getAuthorization() {
		return headers.get("Authorization");
	}
	
	public void setAuthorization(String authValue) {
		removeHeader("Authorization");
		addHeader("Authorization", authValue);
	}
	
	public String getAcceptType() {
		return headers.get("Accept");
	}
	
	public void setAcceptType(String acceptType) {
		removeHeader("Accept");
		addHeader("Accept", acceptType);
	}
	
	public String getContentType() {
		return headers.get("Content-Type");
	}
	
	public void setContentType(String contentType) {
		removeHeader("Content-Type");
		addHeader("Content-Type", contentType);
	}
	
	public void setHeaders(Map<String,String> headers) {
		this.headers = headers;
	}
	
	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	public ApiRequest () {
		requestConfig = RequestConfig.custom()
		.setConnectionRequestTimeout(0)
		.setConnectTimeout(0)
		.setSocketTimeout(0)
		.build();
	}
	
	public ApiResponse execute() throws ApiException {
		validate();
		log("execute", "APIRequest Validation successful");
		
		ApiResponse response = new ApiResponse();

		HttpUriRequest request = null;
		
		switch(method) {
			case GET : request = new HttpGet(url);
				break;
			case POST: request = new HttpPost(url);
				break;
			case PATCH: request = new HttpPatch(url);
				break;
			case PUT: request = new HttpPut(url);
				break;
			case DELETE: request = new HttpDelete(url);
				break;
			default:  throw new ApiException("Unsupported Http Method " + method);
		}
		
		request.setHeaders(ApiUtils.mapToHeaders(headers));
		
		if(method.equals(HttpMethod.POST) || method.equals(HttpMethod.PATCH) || method.equals(HttpMethod.PUT)) {
			try {
				((HttpEntityEnclosingRequestBase)request).setEntity(new StringEntity(body));
			} catch (UnsupportedEncodingException e) {
				throw new ApiException("UnsupportedEncodingException trying to set HTTP Request Body");
			}
		}
		
		try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
	             CloseableHttpResponse httpResponse = httpClient.execute(request)) {
	            
			response.setHttpCode(httpResponse.getStatusLine().getStatusCode());
			response.setMessage(httpResponse.getStatusLine().getReasonPhrase());
			response.setHeaders(ApiUtils.headersToMap(httpResponse.getAllHeaders()));

			HttpEntity responseBody = httpResponse.getEntity();
			if (responseBody != null)
				response.setBody(EntityUtils.toString(responseBody));
	            
		} catch (ParseException e) {
			throw new ApiException("ParseException trying to read HTTP Response");
		} catch (IOException e) {
			throw new ApiException("IOException trying to read HTTP Response");
		}
		
		return response;
	}
	
	private void validate() throws ApiException {
		if(url == null || url.toString().isEmpty())
			throw new ApiException("Missing baseUrl when making HTTP call");
		if(method == null)
			throw new ApiException("Missing method when making HTTP call");
		if(headers == null || headers.size() <= 0)
			throw new ApiException("Missing headers when making HTTP call");
		if(method.equals(HttpMethod.POST) || method.equals(HttpMethod.PATCH) || method.equals(HttpMethod.PUT))
			if(body == null || body.equals(""))
				throw new ApiException("Missing Body when making " + method + " HTTP call");
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	    sb.append("class ApiRequest {\n");
	    sb.append("    URL: ").append(toIndentedString(url.toString())).append("\n");
	    sb.append("    Method: ").append(toIndentedString(method)).append("\n");
	    sb.append("    Headers: ").append(toIndentedString(ApiUtils.parameterToString(headers))).append("\n");
	    sb.append("    body: ").append(toIndentedString(body)).append("\n");
	    sb.append("}");
	    return sb.toString();
	}

	private String toIndentedString(java.lang.Object o) {
		if (o == null)
			return "null";
	    
		return o.toString().replace("\n", "\n    ");
	}
	
	private static void log(String method, String message) {
		logger.debug("Method: " + method + " - " + message);
	}
}
