package com.rli.scripts.customobjects.workday.ldap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchResult;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.workday.ldap.WorkdayWorkerLDAPUtils;
import com.rli.scripts.customobjects.workday.worker.Worker;
import com.rli.util.djava.ScriptHelper;

/*
 * Utility Class for the Workday Worker LDAP interface
 */
public class WorkdayWorkerLDAPUtils {
	private static Logger logger = LogManager.getLogger(WorkdayWorkerLDAPUtils.class);
	
	public static Map<String, String> getAttributesFromFilter(String filter) {
		Map<String, String> result = new HashMap<>();
		try {
			Pattern emailIdPattern = Pattern.compile("(?i)(\\()?email=([a-z0-9_.@-]*)(\\))?");
			Pattern userIdPattern = Pattern.compile("(?i)(\\()?userid=([a-z0-9_-]*)(\\))?");
			Matcher emailIdMatcher = emailIdPattern.matcher(filter);
			Matcher userIdMatcher = userIdPattern.matcher(filter);
			if (emailIdMatcher.find()) {
				result.put("email", emailIdMatcher.group(2));
			} else if (userIdMatcher.find()) {
				result.put("userId", userIdMatcher.group(2));
			}
		} catch(Exception e) {
			logException("getAttributeFromFilterString", e);
		}
		
		return result;
	}
	
	public static List<SearchResult> toResultSet(List<Worker> entries, String baseDN) {
		List<SearchResult> results = new ArrayList<>();
		
		if(entries == null | entries.size() <= 0)
			return results;
		
		for(Worker entry : entries) {
			Attributes attributes = null;
			String targetDN = null;
			
			try {
				attributes = convertToAttributes(entry);
				
				String rdnValue = ScriptHelper.getAttributeValue(attributes.get("empCode"));
				//attributes.put(new BasicAttribute("empCode", rdnValue));
				targetDN = "empCode=" + rdnValue + "," + baseDN;
			} catch(Exception e) {
				log("toResultSet", e.getMessage());
			}
			
			if(targetDN != null) {
				log("toResultSet", "Entry: \"" + targetDN + "\" with " + attributes.size() + " attributes");
				results.add(new SearchResult(targetDN, null, attributes));
			}
		}
		
		return results;
	}
	
	private static Attributes convertToAttributes(Worker worker) {
		Attributes attributes = new BasicAttributes();
		
		if(worker.getActiveStatus() != null)
			attributes.put("ActiveStatus", worker.getActiveStatus().toString());
		if(worker.getBeginDate() != null)
			attributes.put("BeginDate", worker.getBeginDate().toString());
		if(worker.getBusinessTitle() != null)
			attributes.put("BusinessTitle", worker.getBusinessTitle().toString());
		if(worker.getDepartmentCode() != null)
			attributes.put("DepartmentCode", worker.getDepartmentCode().toString());
		if(worker.getDutyCode() != null)
			attributes.put("DutyCode", worker.getDutyCode().toString());
		if(worker.getEmailAddress() != null)
			attributes.put("EmailAddress", worker.getEmailAddress().toString());
		if(worker.getEmployeeCode() != null)
			attributes.put("EmployeeCode", worker.getEmployeeCode().toString());
		if(worker.getEmployment() != null)
			attributes.put("Employment", worker.getEmployment().toString());
		if(worker.getEndDate() != null)
			attributes.put("EndDate", worker.getEndDate().toString());
		if(worker.getIsManager() != null)
			attributes.put("IsManager", worker.getIsManager().toString());
		if(worker.getJobFamily() != null)
			attributes.put("JobFamily", worker.getJobFamily().toString());
		if(worker.getJobFamilyGroup() != null)
			attributes.put("JobFamilyGroup", worker.getJobFamilyGroup().toString());
		if(worker.getJobProfile() != null)
			attributes.put("JobProfile", worker.getJobProfile().toString());
		if(worker.getLocation() != null)
			attributes.put("Location", worker.getLocation().toString());
		if(worker.getManagerName() != null)
			attributes.put("ManagerName", worker.getManagerName().toString());
		if(worker.getManagerID() != null)
			attributes.put("ManagerID", worker.getManagerID().toString());
		if(worker.getManager1() != null)
			attributes.put("Manager1", worker.getManager1().toString());
		if(worker.getManager2() != null)
			attributes.put("Manager2", worker.getManager2().toString());
		if(worker.getManager3() != null)
			attributes.put("Manager3", worker.getManager3().toString());
		if(worker.getManager4() != null)
			attributes.put("Manager4", worker.getManager4().toString());
		if(worker.getManager5() != null)
			attributes.put("Manager5", worker.getManager5().toString());
		if(worker.getManager6() != null)
			attributes.put("Manager6", worker.getManager6().toString());
		if(worker.getManager7() != null)
			attributes.put("Manager7", worker.getManager7().toString());
		if(worker.getManager8() != null)
			attributes.put("Manager8", worker.getManager8().toString());
		if(worker.getManager9() != null)
			attributes.put("Manager9", worker.getManager9().toString());
		if(worker.getMobilePhone() != null)
			attributes.put("MobilePhone", worker.getMobilePhone().toString());
		if(worker.getModifyDate() != null)
			attributes.put("ModifyDate", worker.getModifyDate().toString());
		if(worker.getLegalName() != null)
			attributes.put("LegalName", worker.getLegalName().toString());
		if(worker.getNickName() != null)
			attributes.put("NickName", worker.getNickName().toString());
		if(worker.getOffice() != null)
			attributes.put("Office", worker.getOffice().toString());
		if(worker.getOrganization1() != null)
			attributes.put("Organization1", worker.getOrganization1().toString());
		if(worker.getOrganization2() != null)
			attributes.put("Organization2", worker.getOrganization2().toString());
		if(worker.getOrganization3() != null)
			attributes.put("Organization3", worker.getOrganization3().toString());
		if(worker.getOrganization4() != null)
			attributes.put("Organization4", worker.getOrganization4().toString());
		if(worker.getOrganization5() != null)
			attributes.put("Organization5", worker.getOrganization5().toString());
		if(worker.getOrganization6() != null)
			attributes.put("Organization6", worker.getOrganization6().toString());
		if(worker.getOrganization7() != null)
			attributes.put("Organization7", worker.getOrganization7().toString());
		if(worker.getOrganization8() != null)
			attributes.put("Organization8", worker.getOrganization8().toString());
		if(worker.getOrganization9() != null)
			attributes.put("Organization9", worker.getOrganization9().toString());
		if(worker.getWorkPhone() != null)
			attributes.put("WorkPhone", worker.getWorkPhone().toString());
		if(worker.getPositionCode() != null)
			attributes.put("PositionCode", worker.getPositionCode().toString());
		if(worker.getPositionName() != null)
			attributes.put("PositionName", worker.getPositionName().toString());
		if(worker.getSsn() != null)
			attributes.put("Ssn", worker.getSsn().toString());
		if(worker.getSupervisoryOrganization() != null)
			attributes.put("SupervisoryOrganization", worker.getSupervisoryOrganization().toString());
		if(worker.getTeam() != null)
			attributes.put("Team", worker.getTeam().toString());
		if(worker.getManagementLevel() != null)
			attributes.put("ManagementLevel", worker.getManagementLevel().toString());
		if(worker.getWorkerTypeID() != null)
			attributes.put("WorkerTypeID", worker.getWorkerTypeID().toString());
		if(worker.getWorkerSubType() != null)
			attributes.put("WorkerSubType", worker.getWorkerSubType().toString());
		if(worker.getWorkerType() != null)
			attributes.put("WorkerType", worker.getWorkerType().toString());
        
        return attributes;
	}
	
	private static void log(String method, String message) {
		logger.debug(method + ": " + message); 
	}
	
	private static void logException(String method, Exception exception) {
		if(exception instanceof ApiException) {
			logger.error("Error in " + method + " : " + ((ApiException)exception).getHttpCode());
			logger.error("Error in " + method + " : " + ((ApiException)exception).getApiErrorCode());
		}
		
		logger.error("Error in " + method + " : " + exception.getMessage());
	}
	
}
