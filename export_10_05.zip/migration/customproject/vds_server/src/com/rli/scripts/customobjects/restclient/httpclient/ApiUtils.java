package com.rli.scripts.customobjects.restclient.httpclient;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;

/*
 * Utility Class for the HTTP API Request / Response
 */
public class ApiUtils {
	
	private static JSON json = new JSON();
	
	public static Map<String, String> headersToMap(Header[] headers) {
		Map<String,String> result = new HashMap<>();
		
		for(int i = 0; i < headers.length; i++)
			result.put(headers[i].getName(),headers[i].getValue());
		
		return result;
	}
	
	public static Header[] mapToHeaders(Map<String, String> headers) {
		Header[] result = new Header[headers.size()];
		
		int i = 0;
		for(String key: headers.keySet()) {
			Header header = new BasicHeader(key, headers.get(key));
			result[i] = header;
			i++;
		}
		
		return result;
	}
	
	public static String parameterToString(Object param) {
		if (param == null) {
			return "";
		} else if (param instanceof Date || param instanceof LocalDate) {
			String jsonStr = json.serialize(param);
			return jsonStr.substring(1, jsonStr.length() - 1);
		} else if (param instanceof Collection) {
			StringBuilder b = new StringBuilder();
			for (Object o : (Collection<?>)param) {
				if (b.length() > 0) {
					b.append(",");
				}
				b.append(String.valueOf(o));
			}
			return b.toString();
		} else if (param instanceof Object[]) {
			StringBuilder b = new StringBuilder();
			Object[] items = (Object[])param;
			for (int i = 0; i < items.length; i++) {
				if (b.length() > 0) {
					b.append(",");
				}
				b.append(items[i].toString());
			}
			return b.toString();
		} else {
			return String.valueOf(param);
		}
	}
	
    public static boolean isJsonMime(String mime) {
    	String jsonMime = "(?i)^(application/json|[^;/ \t]+/[^;/ \t]+[+]json)[ \t]*(;.*)?$";
        return mime != null && (mime.matches(jsonMime) || mime.equals("*/*"));
	}
}
