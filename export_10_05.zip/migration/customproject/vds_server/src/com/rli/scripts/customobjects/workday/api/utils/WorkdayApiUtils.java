package com.rli.scripts.customobjects.workday.api.utils;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.client.utils.URIBuilder;

import com.google.gson.reflect.TypeToken;
import com.rli.scripts.customobjects.restclient.httpclient.ApiError;
import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.restclient.httpclient.ApiResponse;
import com.rli.scripts.customobjects.restclient.httpclient.ApiUtils;
import com.rli.scripts.customobjects.restclient.httpclient.JSON;
import com.rli.scripts.customobjects.workday.api.OrganizationApi;
import com.rli.scripts.customobjects.workday.api.WorkerApi;

/*
 * Utility Class for the Worker User API
 */
public class WorkdayApiUtils {
	
	private static JSON json = new JSON();

	public static URI buildUri(String baseUrl, String pathUrl, Map<String,String> pathParams, Map<String,String> queryParams) throws ApiException {
		try {
			URIBuilder builder = new URIBuilder(baseUrl + "/" + replacePathParam(pathUrl, pathParams));
			if(queryParams != null && queryParams.size() > 0) {
				for(String key : queryParams.keySet()) {
					String value = queryParams.get(key); 
					if(value != null && !value.isEmpty())
						builder.setParameter(key, value);
				}
			}
			return(builder.build());
		} catch(URISyntaxException e) {
			throw new ApiException("Exception trying to build URL");
		}
	}
	
	private static String replacePathParam(String pathUrl, Map<String,String> pathParams) throws ApiException {
		if(pathUrl == null || pathUrl.isEmpty())
			throw new ApiException("pathUrl is not set");
		
		List<String> pathParamKeys = new ArrayList<>();
		Pattern pathParamPattern = Pattern.compile("(?i)\\{([a-z]*)\\}");
		Matcher pathParamMatcher = pathParamPattern.matcher(pathUrl);

		try {
			while (pathParamMatcher.find()) {
				pathParamKeys.add(pathParamMatcher.group(1));
			}
		} catch(IllegalStateException e) {
			throw new ApiException("Exception trying to get Path Param Keys" + pathUrl);
		} catch(IndexOutOfBoundsException e) {
			throw new ApiException("Exception trying to get Path Param Keys" + pathUrl);
		}
		
		for(String key : pathParamKeys) {
			if(pathParams != null && pathParams.get(key) != null && !pathParams.get(key).isEmpty())
				pathUrl = pathUrl.replaceAll("\\{" + key + "\\}", pathParams.get(key));
			else
				throw new ApiException("Value not set for required Path Parameter: " + key);
		}
		return pathUrl;
	}
	
	public static String toJSONString(Object object) {
		try {
			return serialize(object, "application/json");
		} catch (ApiException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public static String serialize(Object obj, String contentType) throws ApiException {
        if (ApiUtils.isJsonMime(contentType)) {
            String content;
            if (obj != null) {
                content = json.serialize(obj);
            } else {
                content = null;
            }
            return content;
        } else {
            throw new ApiException("Content type \"" + contentType + "\" is not supported");
        }
    }
	
	@SuppressWarnings( "unchecked" )
	public static <T> T convertTo(Class<?> apiClass, ApiResponse response, Type returnType) throws ApiException {
		if(response.getHttpCode() == null)
			throw new ApiException(0, 0, null, "Http Request not executed");
		
		Boolean requestSuccessful = null;
		if(apiClass.equals(WorkerApi.class)) {
			requestSuccessful = WorkerApi.isSuccessful(response.getHttpCode());
		} else if(apiClass.equals(OrganizationApi.class)) {
			requestSuccessful = OrganizationApi.isSuccessful(response.getHttpCode());
		}
		
		if(!requestSuccessful) {
			String contentType = response.getContentType();
			if(contentType != null && ApiUtils.isJsonMime(contentType)) {
				returnType = new TypeToken<ApiError>(){}.getType();
				ApiError error = deserialize(response.getBody(), returnType);
				throw new ApiException(response.getHttpCode(), error.getCode(), response.getHeaders(), error.getMessage());
			} else {
				throw new ApiException(response.getHttpCode(), 0, response.getHeaders(), "HTTP Error");
			}
		}
		
		if (returnType == null)
			return null;
		
		if(response.getBody() == null || "".equals(response.getBody()))
			throw new ApiException(response.getHttpCode(), 0, null, "Body is empty");
		
	    String contentType = response.getContentType();
	    if (contentType == null)
	    	contentType = "application/json";
	        
	    if (ApiUtils.isJsonMime(contentType)) {
	    	return deserialize(response.getBody(), returnType);
	    } else if (returnType.equals(String.class)) {
	    	return (T) response.getBody();
	    } else {
	    	throw new ApiException(response.getHttpCode(), 0, null, "Content type \"" + contentType + "\" is not supported for type: " + returnType);
	    }
	}
	
	public static <T> T deserialize(String stringObject, Type returnType) throws ApiException {
        if (returnType != null && returnType instanceof Class) {
            if (stringObject != null && !stringObject.equals(""))
                return json.deserialize(stringObject, returnType);
            else
                return null;
        } else {
            throw new ApiException("Deserialization into type \"" + returnType.getTypeName() + "\" is not supported");
        }
    }
}
