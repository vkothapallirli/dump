package com.rli.scripts.customobjects.concurco.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


/**
 *
 *
 *This class contains UserProfile Attributes
 */
@XmlRootElement(name="UserProfile")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserProfile {

	private String EmpId;
	private String FeedRecordNumber;
	private String LoginId;
	private String LocaleName;
	private String LedgerName;
	private String Active;
	private String Password;
	private String FirstName;
	private String LastName;
	private String Mi;
	private String EmailAddress;
	private String LedgerKey;
	private String OrgUnit1;
	private String OrgUnit2;
	private String OrgUnit3;
	private String OrgUnit4;
	private String OrgUnit5;
	private String OrgUnit6;
	private String Custom1;
	private String Custom2;
	private String Custom3;
	private String Custom4;
	private String Custom5;
	private String Custom6;
	private String Custom7;
	private String Custom8;
	private String Custom9;
	private String Custom10;
	private String Custom11;
	private String Custom12;
	private String Custom13;
	private String Custom14;
	private String Custom15;
	private String Custom16;
	private String Custom17;
	private String Custom18;
	private String Custom19;
	private String Custom20;
	private String Custom21;
	private String CtryCode;
	private String CashAdvanceAccountCode;
	private String CrnKey;
	private String CtrySubCode;
	private String ExpenseUser;
	private String ExpenseApprover;
	private String TripUser;
	private String InvoiceUser;
	private String InvoiceApprover;
	private String ExpenseApproverEmployeeID;
	private String NewLoginID;
	private String NewEmployeeID;

	public String getEmpId() {
		return EmpId;
	}

	public void setEmpId(String empId) {
		EmpId = empId;
	}

	public String getFeedRecordNumber() {
		return FeedRecordNumber;
	}

	public void setFeedRecordNumber(String feedRecordNumber) {
		FeedRecordNumber = feedRecordNumber;
	}

	public String getLoginId() {
		return LoginId;
	}

	public void setLoginId(String loginId) {
		LoginId = loginId;
	}

	public String getLocaleName() {
		return LocaleName;
	}

	public void setLocaleName(String localeName) {
		LocaleName = localeName;
	}

	public String getActive() {
		return Active;
	}

	public void setActive(String active) {
		Active = active;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getFirstName() {
		return FirstName;
	}

	
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getMi() {
		return Mi;
	}

	public void setMi(String mi) {
		Mi = mi;
	}

	public String getEmailAddress() {
		return EmailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}

	public String getLedgerKey() {
		return LedgerKey;
	}

	public void setLedgerKey(String ledgerKey) {
		LedgerKey = ledgerKey;
	}

	public String getOrgUnit1() {
		return OrgUnit1;
	}

	public void setOrgUnit1(String orgUnit1) {
		OrgUnit1 = orgUnit1;
	}

	public String getOrgUnit2() {
		return OrgUnit2;
	}

	public void setOrgUnit2(String orgUnit2) {
		OrgUnit2 = orgUnit2;
	}

	public String getOrgUnit3() {
		return OrgUnit3;
	}

	public void setOrgUnit3(String orgUnit3) {
		OrgUnit3 = orgUnit3;
	}

	public String getOrgUnit4() {
		return OrgUnit4;
	}

	public void setOrgUnit4(String orgUnit4) {
		OrgUnit4 = orgUnit4;
	}

	public String getOrgUnit5() {
		return OrgUnit5;
	}

	public void setOrgUnit5(String orgUnit5) {
		OrgUnit5 = orgUnit5;
	}

	public String getOrgUnit6() {
		return OrgUnit6;
	}

	public void setOrgUnit6(String orgUnit6) {
		OrgUnit6 = orgUnit6;
	}

	public String getCustom1() {
		return Custom1;
	}

	public void setCustom1(String custom1) {
		Custom1 = custom1;
	}

	public String getCustom2() {
		return Custom2;
	}

	public void setCustom2(String custom2) {
		Custom2 = custom2;
	}

	public String getCustom3() {
		return Custom3;
	}

	public void setCustom3(String custom3) {
		Custom3 = custom3;
	}

	public String getCustom4() {
		return Custom4;
	}

	public void setCustom4(String custom4) {
		Custom4 = custom4;
	}

	public String getCustom5() {
		return Custom5;
	}

	public void setCustom5(String custom5) {
		Custom5 = custom5;
	}

	public String getCustom6() {
		return Custom6;
	}

	public void setCustom6(String custom6) {
		Custom6 = custom6;
	}

	public String getCustom7() {
		return Custom7;
	}

	public void setCustom7(String custom7) {
		Custom7 = custom7;
	}

	public String getCustom8() {
		return Custom8;
	}

	public void setCustom8(String custom8) {
		Custom8 = custom8;
	}

	public String getCustom9() {
		return Custom9;
	}

	public void setCustom9(String custom9) {
		Custom9 = custom9;
	}

	public String getCustom10() {
		return Custom10;
	}

	public void setCustom10(String custom10) {
		Custom10 = custom10;
	}

	public String getCustom11() {
		return Custom11;
	}

	public void setCustom11(String custom11) {
		Custom11 = custom11;
	}

	public String getCustom12() {
		return Custom12;
	}

	public void setCustom12(String custom12) {
		Custom12 = custom12;
	}

	public String getCustom13() {
		return Custom13;
	}

	public void setCustom13(String custom13) {
		Custom13 = custom13;
	}

	public String getCustom14() {
		return Custom14;
	}

	public void setCustom14(String custom14) {
		Custom14 = custom14;
	}

	public String getCustom15() {
		return Custom15;
	}

	public void setCustom15(String custom15) {
		Custom15 = custom15;
	}

	public String getCustom16() {
		return Custom16;
	}

	public void setCustom16(String custom16) {
		Custom16 = custom16;
	}

	public String getCustom17() {
		return Custom17;
	}

	public void setCustom17(String custom17) {
		Custom17 = custom17;
	}

	public String getCustom18() {
		return Custom18;
	}

	public void setCustom18(String custom18) {
		Custom18 = custom18;
	}

	public String getCustom19() {
		return Custom19;
	}

	public void setCustom19(String custom19) {
		Custom19 = custom19;
	}

	public String getCustom20() {
		return Custom20;
	}

	public void setCustom20(String custom20) {
		Custom20 = custom20;
	}

	public String getCustom21() {
		return Custom21;
	}

	public void setCustom21(String custom21) {
		Custom21 = custom21;
	}

	public String getCtryCode() {
		return CtryCode;
	}

	public void setCtryCode(String ctryCode) {
		CtryCode = ctryCode;
	}

	public String getCashAdvanceAccountCode() {
		return CashAdvanceAccountCode;
	}

	public void setCashAdvanceAccountCode(String cashAdvanceAccountCode) {
		CashAdvanceAccountCode = cashAdvanceAccountCode;
	}

	public String getCrnKey() {
		return CrnKey;
	}

	public void setCrnKey(String crnKey) {
		CrnKey = crnKey;
	}

	public String getCtrySubCode() {
		return CtrySubCode;
	}

	public void setCtrySubCode(String ctrySubCode) {
		CtrySubCode = ctrySubCode;
	}

	public String getExpenseUser() {
		return ExpenseUser;
	}

	public void setExpenseUser(String expenseUser) {
		ExpenseUser = expenseUser;
	}

	public String getExpenseApprover() {
		return ExpenseApprover;
	}

	public void setExpenseApprover(String expenseApprover) {
		ExpenseApprover = expenseApprover;
	}

	public String getTripUser() {
		return TripUser;
	}

	public void setTripUser(String tripUser) {
		TripUser = tripUser;
	}

	public String getInvoiceUser() {
		return InvoiceUser;
	}

	public void setInvoiceUser(String invoiceUser) {
		InvoiceUser = invoiceUser;
	}

	public String getInvoiceApprover() {
		return InvoiceApprover;
	}

	public void setInvoiceApprover(String invoiceApprover) {
		InvoiceApprover = invoiceApprover;
	}

	public String getExpenseApproverEmployeeID() {
		return ExpenseApproverEmployeeID;
	}

	public void setExpenseApproverEmployeeID(String expenseApproverEmployeeID) {
		ExpenseApproverEmployeeID = expenseApproverEmployeeID;
	}

	public String getNewLoginID() {
		return NewLoginID;
	}

	public void setNewLoginID(String newLoginID) {
		NewLoginID = newLoginID;
	}

	public String getNewEmployeeID() {
		return NewEmployeeID;
	}

	public void setNewEmployeeID(String newEmployeeID) {
		NewEmployeeID = newEmployeeID;
	}

	public String getLedgerName() {
		return LedgerName;
	}

	public void setLedgerName(String ledgerName) {
		LedgerName = ledgerName;
	}

}
