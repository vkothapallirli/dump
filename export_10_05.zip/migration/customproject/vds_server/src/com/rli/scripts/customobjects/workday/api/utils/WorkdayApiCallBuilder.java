package com.rli.scripts.customobjects.workday.api.utils;

import java.util.HashMap;
import java.util.Map;

import com.rli.scripts.customobjects.restclient.auth.HttpBasic;
import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.restclient.httpclient.ApiRequest;
import com.rli.scripts.customobjects.restclient.httpclient.ApiRequest.HttpMethod;
import com.rli.scripts.customobjects.workday.api.OrganizationApi;
import com.rli.scripts.customobjects.workday.api.WorkerApi;
import com.rli.scripts.customobjects.workday.worker.GetAllWorkersRequest;
import com.rli.scripts.customobjects.workday.organization.GetAllOrganizationsRequest;

/*
 * Class that is used for converting the Request Objects to HTTP API Requests
 */
public class WorkdayApiCallBuilder {
	
	public static ApiRequest buildGetAllWorkers(GetAllWorkersRequest request) throws ApiException {
		//Query Params
		Map<String,String> queryParams = new HashMap<>();
        //Required		
        if (request.getFormat() != null)
        	queryParams.put("format", request.getFormat());
        //Base URL
        String baseUrl = WorkerApi.getBaseUrl();
        //Path URL and params
        String pathUrl = WorkerApi.getResource();
        //ApiRequest
        ApiRequest apiRequest = new ApiRequest();
        apiRequest.setUrl(WorkdayApiUtils.buildUri(baseUrl, pathUrl, null, queryParams));
        apiRequest.setAcceptType("application/json");
        apiRequest.setAuthorization(HttpBasic.getToken());
        apiRequest.setMethod(HttpMethod.GET);
        
        return apiRequest;
    }
	
	public static ApiRequest buildGetAllOrganizations(GetAllOrganizationsRequest request) throws ApiException {
		//Query Params
		Map<String,String> queryParams = new HashMap<>();
        //Required
        if (request.getFormat() != null)
        	queryParams.put("format", request.getFormat());
        //Base URL
        String baseUrl = OrganizationApi.getBaseUrl();
        //Path URL and params
        String pathUrl = OrganizationApi.getResource();
        //ApiRequest
        ApiRequest apiRequest = new ApiRequest();
        apiRequest.setUrl(WorkdayApiUtils.buildUri(baseUrl, pathUrl, null, queryParams));
        apiRequest.setAcceptType("application/json");
        apiRequest.setAuthorization(HttpBasic.getToken());
        apiRequest.setMethod(HttpMethod.GET);
        
        return apiRequest;
    }
    
}
