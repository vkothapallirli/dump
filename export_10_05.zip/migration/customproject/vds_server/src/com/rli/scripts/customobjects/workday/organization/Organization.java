package com.rli.scripts.customobjects.workday.organization;

import com.google.gson.annotations.SerializedName;

/*
 * Class representing an Organization
 */
public class Organization {
  
  @SerializedName("DEPT_NAME")
  private String departmentName = null;

  @SerializedName("DEPT_CODE")
  private String departmentCode = null;

  @SerializedName("PAR_CODE")
  private String parentCode = null;
  
  public Organization departmentName(String departmentName) {
	this.departmentName = departmentName;
	return this;
  }

  public String getDepartmentName() {
	if(departmentName != null && !departmentName.isEmpty())
	  return departmentName;
	else
	  return null;
  }

  public void setDepartmentName(String departmentName) {
    if(departmentName == null || !departmentName.equals(""))
      this.departmentName = departmentName;
  }

  public Organization departmentCode(String departmentCode) {
    this.departmentCode = departmentCode;
    return this;
  }

  public String getDepartmentCode() {
	if(departmentCode != null && !departmentCode.isEmpty())
      return departmentCode;
	else
	  return null;
  }

  public void setDepartmentCode(String departmentCode) {
	  if(departmentCode == null || !departmentCode.equals(""))
		  this.departmentCode = departmentCode;
  }

  public Organization parentCode(String parentCode) {
    this.parentCode = parentCode;
    return this;
  }

  public String getParentCode() {
    if(parentCode != null && !parentCode.isEmpty())
      return parentCode;
    else
      return null;
  }

  public void setParentCode(String parentCode) {
    if(parentCode == null || !parentCode.equals(""))
      this.parentCode = parentCode;
  }
  
  public Boolean isEmpty() {
	  return (
			  (departmentName == null || departmentName.isEmpty()) &&
			  (departmentCode == null || departmentCode.isEmpty()) &&
			  (parentCode == null || parentCode.isEmpty())
			  );
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Organization {\n");
    sb.append("    departmentName: ").append(toIndentedString(departmentName)).append("\n");
    sb.append("    departmentCode: ").append(toIndentedString(departmentCode)).append("\n");
    sb.append("    parentCode: ").append(toIndentedString(parentCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
