package com.rli.scripts.customobjects.workday.api;

import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.workday.organization.GetAllOrganizationsRequest;
import com.rli.scripts.customobjects.workday.organization.GetAllOrganizationsResponse;
import com.rli.scripts.customobjects.workday.worker.GetAllWorkersRequest;
import com.rli.scripts.customobjects.workday.worker.GetAllWorkersResponse;
import com.rli.synsvcs.common.ConnString2;
import com.rli.tools.sync.cacherefresh.stringvdshandler.VDSSyntaxException;

/*
 * Testing Class for the Workday API
 */
public class WorkdayAPITestClient {
	
	private WorkerApi workerApi;
	private OrganizationApi organizationApi;
	
	public WorkdayAPITestClient() {
		workerApi = getWorkerApi();
		organizationApi = getOrganizationApi();
	}
	
	public static void main(String[] args) {
		WorkdayAPITestClient test = new WorkdayAPITestClient();
		test.getAllWorkersTest();
		//test.getAllOrganizationsTest();
	}

	private static WorkerApi getWorkerApi() {
		WorkerApi api = null;
		ConnString2 conn;
		try{
			conn = new ConnString2("datasourcename=workdayworkers");
			String url = conn.getUrl();
			String resource = conn.getCustomProperty("resource");
			String username = conn.getUsername();
			String password = conn.getPassword();
			
			log("getWorkerApi", "BaseUrl: " + url);
			log("getWorkerApi", "Resource: " + resource);
			log("getWorkerApi", "Username: " + username);
			log("getWorkerApi", "Password: " + password.replaceAll(".", "*"));
			//log("getWorkerApi", "Password New: " + password);

			log("getWorkerApi", "Creating Workday Conection");
			api = new WorkerApi(url, resource, username, password);
			log("getWorkerApi", "Workday Conection successful");
		} catch (VDSSyntaxException e) {
			log("getWorkerApi", "Workday Conection failed");
			logException("getWorkerApi", e);
		}
		return api;
	}
	
	private static OrganizationApi getOrganizationApi() {
		OrganizationApi api = null;
		ConnString2 conn;
		try{
			conn = new ConnString2("datasourcename=workdayorganizations");
			String url = conn.getUrl();
			String resource = conn.getCustomProperty("resource");
			String username = conn.getUsername();
			String password = conn.getPassword();
			
			log("getOrganizationApi", "BaseUrl: " + url);
			log("getOrganizationApi", "Resource: " + resource);
			log("getOrganizationApi", "Username: " + username);
			log("getOrganizationApi", "Password: " + password.replaceAll(".", "*"));

			log("getOrganizationApi", "Creating Workday Conection");
			api = new OrganizationApi(url, resource, username, password);
			log("getOrganizationApi", "Workday Conection successful");
		} catch (VDSSyntaxException e) {
			log("getOrganizationApi", "Workday Conection failed");
			logException("getOrganizationApi", e);
		}
		return api;
	}
	
	public void getAllWorkersTest() {
    	String format = "json";
    	
    	GetAllWorkersRequest request = new GetAllWorkersRequest(format);
    	
    	GetAllWorkersResponse response = null;
    	
    	try {
        	response = workerApi.getAllWorkers(request);
        } catch (ApiException e) {
        	logException("getAllWorkersTest", e);
        }
        
    	if(response == null) {
			return;
		}
    	
    	log("getAllOrganizationsTest", response.toString());
    }
	
	public void getAllOrganizationsTest() {
    	String format = "json";
    	
    	GetAllOrganizationsRequest request = new GetAllOrganizationsRequest(format);
    	
    	GetAllOrganizationsResponse response = null;
    	
    	try {
        	response = organizationApi.getAllOrganizations(request);
        } catch (ApiException e) {
        	logException("getAllOrganizationsTest", e);
        }
        
    	if(response == null) {
			return;
		}
    	
    	log("getAllOrganizationsTest", response.toString());
    }
    
    private static void logException(String method, Exception e) {
    	if(e instanceof ApiException) {
    		System.out.println("Error in " + "Method: " + method + " - " + "ExceptionCode: " + ((ApiException) e).getHttpCode());
    		System.out.println("Error in " + "Method: " + method + " - " + "ExceptionCode: " + ((ApiException) e).getApiErrorCode());
    	}
    	System.out.println("Error in " + "Method: " + method + " - " + "ExceptionMessage: " + e.getMessage());
	}
    
    private static void log(String method, String message) {
    	System.out.println("Method: " + method + " - " + message);
    }
    
}