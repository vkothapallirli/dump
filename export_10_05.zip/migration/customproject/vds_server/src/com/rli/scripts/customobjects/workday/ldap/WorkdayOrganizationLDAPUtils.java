package com.rli.scripts.customobjects.workday.ldap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchResult;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.workday.ldap.WorkdayOrganizationLDAPUtils;
import com.rli.scripts.customobjects.workday.organization.Organization;
import com.rli.util.djava.ScriptHelper;

/*
 * Utility Class for the Workday Worker LDAP interface
 */
public class WorkdayOrganizationLDAPUtils {
	private static Logger logger = LogManager.getLogger(WorkdayOrganizationLDAPUtils.class);
	
	public static Map<String, String> getAttributesFromFilter(String filter) {
		Map<String, String> result = new HashMap<>();
		try {
			Pattern emailIdPattern = Pattern.compile("(?i)(\\()?email=([a-z0-9_.@-]*)(\\))?");
			Pattern userIdPattern = Pattern.compile("(?i)(\\()?userid=([a-z0-9_-]*)(\\))?");
			Matcher emailIdMatcher = emailIdPattern.matcher(filter);
			Matcher userIdMatcher = userIdPattern.matcher(filter);
			if (emailIdMatcher.find()) {
				result.put("email", emailIdMatcher.group(2));
			} else if (userIdMatcher.find()) {
				result.put("userId", userIdMatcher.group(2));
			}
		} catch(Exception e) {
			logException("getAttributeFromFilterString", e);
		}
		
		return result;
	}
	
	public static List<SearchResult> toResultSet(List<Organization> entries, String baseDN) {
		List<SearchResult> results = new ArrayList<>();
		
		if(entries == null | entries.size() <= 0)
			return results;
		
		for(Organization entry : entries) {
			Attributes attributes = null;
			String targetDN = null;
			
			try {
				attributes = convertToAttributes(entry);
				
				String rdnValue = ScriptHelper.getAttributeValue(attributes.get("DeptCode"));
				//attributes.put(new BasicAttribute("DeptCode", rdnValue));
				targetDN = "DeptCode=" + rdnValue + "," + baseDN;
			} catch(Exception e) {
				log("toResultSet", e.getMessage());
			}
			
			if(targetDN != null) {
				log("toResultSet", "Entry: \"" + targetDN + "\" with " + attributes.size() + " attributes");
				results.add(new SearchResult(targetDN, null, attributes));
			}
		}
		
		return results;
	}
	
	private static Attributes convertToAttributes(Organization organization) {
		Attributes attributes = new BasicAttributes();
		
		if(organization.getDepartmentName() != null)
			attributes.put("DepartmentName", organization.getDepartmentName().toString());
		String departmentCode = organization.getDepartmentCode();
		if(departmentCode != null) {
			attributes.put("DepartmentCode", departmentCode.toString());
			String ouCode = departmentCode.replaceAll("SUP", "");
			attributes.put("OuCode", ouCode);
		}
		if(organization.getParentCode() != null)
			attributes.put("ParentCode", organization.getParentCode().toString());
        
        return attributes;
	}
	
	private static void log(String method, String message) {
		logger.debug(method + ": " + message); 
	}
	
	private static void logException(String method, Exception exception) {
		if(exception instanceof ApiException) {
			logger.error("Error in " + method + " : " + ((ApiException)exception).getHttpCode());
			logger.error("Error in " + method + " : " + ((ApiException)exception).getApiErrorCode());
		}
		
		logger.error("Error in " + method + " : " + exception.getMessage());
	}
	
}
