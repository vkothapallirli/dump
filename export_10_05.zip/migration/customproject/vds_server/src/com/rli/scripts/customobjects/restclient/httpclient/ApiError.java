package com.rli.scripts.customobjects.restclient.httpclient;

import com.google.gson.annotations.SerializedName;

/*
 * Class representing Zoom API error codes and messages
 */
public class ApiError {
	@SerializedName("code")
	private Integer code;
	
	@SerializedName("message")
	private String message;
	
	public ApiError code(Integer code) {
		this.code = code;
		return this;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}
	
	public ApiError message(String message) {
		this.message = message;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
