package com.rli.scripts.customobjects.workday.api;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.reflect.TypeToken;
import com.rli.scripts.customobjects.restclient.auth.HttpBasic;
import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.restclient.httpclient.ApiRequest;
import com.rli.scripts.customobjects.restclient.httpclient.ApiResponse;
import com.rli.scripts.customobjects.workday.api.utils.WorkdayApiCallBuilder;
import com.rli.scripts.customobjects.workday.api.utils.WorkdayApiUtils;
import com.rli.scripts.customobjects.workday.api.utils.WorkdayApiValidator;
import com.rli.scripts.customobjects.workday.worker.GetAllWorkersRequest;
import com.rli.scripts.customobjects.workday.worker.GetAllWorkersResponse;

/*
 * Class representing the Worker API
 */
public class WorkerApi {
	
	private static Logger logger = LogManager.getLogger(WorkerApi.class);
	
	private static String baseUrl;
	private static String resource;
	private static List<Integer> sucessCodes = new ArrayList<>();
	
    public static String getBaseUrl() {
		return baseUrl;
	}

	public static void setBaseUrl(String baseUrl) {
		WorkerApi.baseUrl = baseUrl;
	}

	public static String getResource() {
		return resource;
	}

	public static void setResource(String resource) {
		WorkerApi.resource = resource;
	}
	
	public static List<Integer> getSuccessCode() {
		return sucessCodes;
	}
	
	public static void addSuccessCode(Integer code) {
		sucessCodes.add(code);
	}
	
	public static Boolean isSuccessful(Integer httpCode) {
		return sucessCodes.contains(httpCode);
	}
	
	/*
	 * This class can be instantiated by passing 
	 * 		Base API URL of Workday Instance
	 *  	Name of the Custom Worker Report
	 * 		Username and Password for Basic Auth
	 */
	public WorkerApi(String baseUrl, String resource, String username, String password) {
    	WorkerApi.baseUrl = baseUrl;
    	WorkerApi.resource = resource;
    	
        HttpBasic.setCredentials(username, password);
        
        addSuccessCode(200);
    }
    
	/*
	 * Method to get all workers in the Zoom Application in a paged manner
	 */
    public GetAllWorkersResponse getAllWorkers(GetAllWorkersRequest request) throws ApiException {
    	long begin = System.currentTimeMillis();
    	
    	//Validate parameters in the Request Object
        WorkdayApiValidator.validateGetAllWorkers(request);
        log("getAllWorkers", "Request Validations successful");
        
        //Build the HTTP API Call from the parameters of Request Object
        log("getAllWorkers", "Building APIRequest");
        ApiRequest apiRequest = WorkdayApiCallBuilder.buildGetAllWorkers(request);
        long callBuiling = System.currentTimeMillis();
        
        //Execute the HTTP API Call and get the HTTP API Response
        log("getAllWorkers", "Executing the call - " + apiRequest.toString());
    	ApiResponse apiResponse = apiRequest.execute();
    	log("getAllWorkers", "Got Response - " + apiResponse.toString());
    	long responseReceived = System.currentTimeMillis();
    	
    	//Convert the HTTP API Response JSON to Response Object
    	Type returnType = new TypeToken<GetAllWorkersResponse>(){}.getType();
    	log("getAllWorkers", "Converting Response to " + returnType.getTypeName());
    	GetAllWorkersResponse resp = WorkdayApiUtils.convertTo(this.getClass(), apiResponse, returnType);
    	long responseParsing = System.currentTimeMillis();
    	
    	log("getAllWorkers", "Time taken to Validate and Build Request: " + (callBuiling - begin));
    	log("getAllWorkers", "Time Taken to Get Response: " + (responseReceived - callBuiling));
    	log("getAllWorkers", "Time taken to Convert Response: " + (responseParsing - responseReceived));
    	log("getAllWorkers", "Total time: " + (responseParsing - begin));
    	
    	//Return the Response Object
        return resp;
    }
    
    private static void log(String method, String message) {
		logger.debug("Method: " + method + " - " + message);
		//System.out.println("Method: " + method + " - " + message);
	}
    
}
