package com.rli.scripts.customobjects.restclient.auth;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/*
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
*/

/*
 * Utility Class for the Auth methods
 */
public class AuthUtils {
	
	/*
	private static Logger logger = LogManager.getLogger(AuthUtils.class);
	*/
	
	public static Boolean verifyBasic(String username, String password, String token) {
		Boolean status = true;
		status = token.equals(generateBasic(username, password));
		return status;
	}
	
	public static String generateBasic(String username, String password) {
		String credentials = username + ":" + password;
		byte[] encodedCredentials = Base64.getEncoder().encode(credentials.getBytes(StandardCharsets.UTF_8));
		return (new String(encodedCredentials));
	}
	
	/*
	private static void logException(String method, Exception exception) {
		logger.error("Error in " + method + " : " + exception.getMessage());
	}
	
	private static void log(String method, String message) {
		logger.debug("Method: " + method + " - " + message);
	}
	
	private static void info(String method, String message) {
		logger.info("Method: " + method + " - " + message);
	}
	*/
	
}
