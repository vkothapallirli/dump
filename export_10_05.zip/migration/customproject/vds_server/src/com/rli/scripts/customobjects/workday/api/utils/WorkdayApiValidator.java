package com.rli.scripts.customobjects.workday.api.utils;

import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.workday.worker.GetAllWorkersRequest;
import com.rli.scripts.customobjects.workday.organization.GetAllOrganizationsRequest;

/*
 * Class that is used for validating the parameters of the Request Objects
 */
public class WorkdayApiValidator {
	
    public static void validateGetAllWorkers(GetAllWorkersRequest request) throws ApiException {
    	if (request == null)
            throw new ApiException("Missing request params when calling Get All Workers API");
    	if (request.getFormat() == null || request.getFormat().isEmpty())
            throw new ApiException("Missing/Empty the required parameter 'format' when calling Get All Workers API");
    }
    
    public static void validateGetAllOrganizations(GetAllOrganizationsRequest request) throws ApiException {
    	if (request == null)
            throw new ApiException("Missing request params when calling Get All Organizations API");
    	if (request.getFormat() == null || request.getFormat().isEmpty())
            throw new ApiException("Missing/Empty the required parameter 'format' when calling Get All Organizations API");
    }
	
}
