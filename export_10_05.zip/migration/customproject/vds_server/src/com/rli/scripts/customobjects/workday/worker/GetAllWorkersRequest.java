package com.rli.scripts.customobjects.workday.worker;

/*
 * Class representing the Request body for Get All Workers API Call
 */
public class GetAllWorkersRequest {

	private String format;

	public GetAllWorkersRequest(String format) {
		this.format = format;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	  @Override
	  public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("class GetAllWorkersRequest {\n");
	    sb.append("    format: ").append(toIndentedString(format)).append("\n");
	    sb.append("}");
	    return sb.toString();
	  }

	  private String toIndentedString(java.lang.Object o) {
	    if (o == null) {
	      return "null";
	    }
	    return o.toString().replace("\n", "\n    ");
	  }
}
