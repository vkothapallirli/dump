package com.rli.scripts.customobjects;

import java.util.ArrayList;
import java.util.List;
import javax.naming.directory.SearchResult;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rli.scripts.customobjects.restclient.httpclient.ApiException;
import com.rli.scripts.customobjects.workday.api.OrganizationApi;
import com.rli.scripts.customobjects.workday.ldap.WorkdayOrganizationLDAPUtils;
import com.rli.scripts.customobjects.workday.organization.GetAllOrganizationsRequest;
import com.rli.scripts.customobjects.workday.organization.GetAllOrganizationsResponse;
import com.rli.util.djava.ScriptHelper;
import com.rli.vds.util.InterceptParam;
import com.rli.vds.util.UserDefinedInterception2;

public class WorkdayOrganization implements UserDefinedInterception2 {
	
	private static Logger logger = LogManager.getLogger(WorkdayOrganization.class);
	
	/*
	 * Called when a Test Connection is called on the Workday Datasource
	 * Step 1: Create connection to Workday API 
	 * Step 2: Make Workday API call to get one organization 
	 * Step 3: Return success if organization is returned
	 */
	@Override
	public void testConnectToBackend(InterceptParam prop) {
		//Step 1: Create connection to Zoom API 
		OrganizationApi api = getWorkdayOrganizationApi(prop);
		
		//Create the get request
		GetAllOrganizationsRequest request = new GetAllOrganizationsRequest("json");
		GetAllOrganizationsResponse response = null;

		try {
			info("testConnectToBackend", "Making getOrganizations call using Workday Organization API Object");
			//Send the request using the connection
			response = api.getAllOrganizations(request);
			
			//Check if the response is empty / null
			if(response == null)
				throw new ApiException(404, 0, null, "API call returned Nothing");
			
			//Check if the response contains atleast one organization
			if(response.getOrganizations() == null || response.getOrganizations().size() <= 0)
				throw new ApiException(32, 0, null, "No Organization(s) Returned");
			
		} catch (ApiException e) {
			//In case of any error in the API Call throw LDAP error and return failure
    		logException("testConnectToBackend", e);
    		prop.setStatusFailed();
			prop.setErrorcode(e.getHttpCode());
			prop.setErrormessage("Code: " + e.getApiErrorCode() + " \nMessage: " + e.getMessage());
			return;
		}
		
		//If there are no errors return success
		info("testConnectToBackend", "Success");
		prop.setStatusOk();
	}

	
	@Override
	public void insert(InterceptParam prop) {
		//No action
	}

	/*
	 * Called when FID triggers a cache refresh on the Workday Organization View
	 */
	@Override
	public void select(InterceptParam prop) {
		//Get connection to Zoom
		OrganizationApi api = getWorkdayOrganizationApi(prop);
		
		//Get parameters from LDAP Request 
		String dn = prop.getDn();
		String baseDN = ScriptHelper.right(dn, ",");
		baseDN = (baseDN.isEmpty()) ? dn : baseDN;
		log("select", "DN: " + dn);
		log("select", "BaseDN: " + baseDN);

		List<SearchResult> resultSet = new ArrayList<>();

		info("select", "Getting All Organizations");
		//Count variables
		int totalOrganizations = 0;

		//Create the get request and response
		GetAllOrganizationsRequest request = new GetAllOrganizationsRequest("json");
		GetAllOrganizationsResponse response = null;

		try {
			//Send the request using the connection
			response = api.getAllOrganizations(request);

			//Check if the response is empty / null
			if(response == null)
				throw new ApiException(404, 0, null, "API call returned Nothing");
			
			log("select", response.toString());
			
			//Check if the response contains atleast one organization
			if(response.getOrganizations() == null || response.getOrganizations().size() <= 0)
				throw new ApiException(32, 0, null, "No Organization(s) Returned");
		} catch (ApiException e) {
			//In case of any error in the API Call throw LDAP error and return
		    logException("select", e);
		    prop.setStatusFailed();
			prop.setErrorcode(e.getHttpCode());
			prop.setErrormessage("Code: " + e.getApiErrorCode() + " \nMessage: " + e.getMessage());
			return;
		}
		
		//If there are no errors
		//Process and add the organizations to resultset
		totalOrganizations = response.getOrganizations().size();
		resultSet.addAll(WorkdayOrganizationLDAPUtils.toResultSet(response.getOrganizations(), baseDN));
		
		//If there are no errors return the fetched organizations and return success
		info("select", "Success - Returning " + totalOrganizations + " organization(s)");
		prop.setResultSet(resultSet);
		prop.setStatusOk();
	}

	@Override
	public void update(InterceptParam prop) {
		//No Action
	}
	
	@Override
	public void delete(InterceptParam prop) {
		//No Action
	}
	
	@Override
	public void authenticate(InterceptParam prop) {
		//No Action
	}

	@Override
	public void compare(InterceptParam prop) {
		//No Action
	}
	
	@Override
	public void invoke(InterceptParam prop) {
		//No Action
	}
	
	private OrganizationApi getWorkdayOrganizationApi(InterceptParam prop) {
		String url = prop.getConnectionstringUrl();
		String resource = prop.getConnectionstringObject().getCustomProperty("resource");
		String username = prop.getConnectionstringUsername();
		String password = prop.getConnectionstringPassword();

		log("getWorkdayOrganizationApi", "Url: " + url);
		log("getWorkdayWorkerApi", "Resource: " + resource);
		log("getWorkdayOrganizationApi", "Username: " + username);
		log("getWorkdayOrganizationApi", "Password: " + password.replaceAll(".", "*"));

		info("getWorkdayOrganizationApi", "Creating Workday Organization API Object");
		OrganizationApi api = new OrganizationApi(url, resource, username, password);
		info("getWorkdayOrganizationApi", "Created Workday Organization API Object");
		
		return api;
	}
	
	private void info(String method, String message) {
		logger.info(method + " : " + message);
	}
	
	private void log(String method, String message) {
		logger.debug(method + " : " + message);
	}
	
	private void logException(String method, Exception exception) {
		if(exception instanceof ApiException) {
    		logger.error("Error in " + "Method: " + method + " - " + "ExceptionCode: " + ((ApiException) exception).getHttpCode());
    		logger.error("Error in " + "Method: " + method + " - " + "ExceptionCode: " + ((ApiException) exception).getApiErrorCode());
    	}
    	logger.error("Error in " + "Method: " + method + " - " + "ExceptionMessage: " + exception.getMessage());
	}
	
}
